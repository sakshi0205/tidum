import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  user: User = new User();
  submitted = false;
  array: any;
  accountNo : any;
  result : any;
  constructor(private router: Router, private userService: UserService) {}

  newUser(): void {
    this.submitted = false;
    this.user= new User();
  }
  ngOnInit(){

  }

  createUser(): void {
    this.userService.createAccount(this.user)
        .subscribe( data => { this.array = data;
          if(this.array!= null){
            console.log("Your Account Created with account number:"+this.array.accountNo);
            this.result = "Your Account Created with account number:"+this.array.accountNo; 
            //this.accountNo = this.array.accountNo;
          }
          else{
            console.log("Registrantion failed");
            this.result = "Registrantion failed";
          }
        });

  };

  onSubmit() {
    this.submitted = true;
    this.createUser();
  }

}
