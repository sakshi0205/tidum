import { Component, OnInit } from '@angular/core';
import {User} from '../user'
import { Router } from '@angular/router';
import { UserService } from '../user.service';
@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {

  user: User = new User();
  submitted = false;
  result : any;
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit() {
  }

  showBalance(): void {
    this.userService.showBalance(this.user).subscribe(data=>{
      this.result = data;
      console.log(this.result);
    });
  };

  onSubmit() {
    this.submitted = true;
    this.showBalance();
  }

}
