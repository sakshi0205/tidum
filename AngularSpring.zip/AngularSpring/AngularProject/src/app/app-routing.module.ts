import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './withdraw-amount/withdraw-amount.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';



const routes: Routes = [
  { path: '', component : HomeComponent},
  { path: 'createAccount', component: CreateAccountComponent },
  {path : 'showBalance', component : ShowBalanceComponent},
  {path : 'deposit', component : DepositAmountComponent},
  {path : 'withdraw', component : WithdrawAmountComponent},
  {path : 'fundtransfer', component : FundtransferComponent},
  {path : 'printTransaction', component : PrintTransactionComponent}



];

@NgModule({
  declarations: [],
  imports: [RouterModule.forRoot(routes),
  CommonModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
