import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {
  user: User = new User();
  submitted = false;
  result : any;
  fresult: any;
  constructor(private router: Router, private userService: UserService) {}

  ngOnInit() {
  }

  fundTransfer(): void {
    this.userService.fundTransfer(this.user).subscribe(data=>{
      this.result = data;
      console.log(this.result);
      if(this.result == null){
        this.fresult = "Fund Transfer Failed:Check Credenntials";
      }
      else{
        this.fresult = "Fund Transfer successful";
      }
    });
  };


  onSubmit() {
    this.submitted = true;
    this.fundTransfer();
  }

}
