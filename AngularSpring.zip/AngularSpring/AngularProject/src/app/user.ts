export class User {
    userName : string;
    password : string;
    userEmailId : string;
    userPhoneNo : string;
    accountNo : any;
    balance : number;
    amount :  any;
    destAccountNo:any;
}
