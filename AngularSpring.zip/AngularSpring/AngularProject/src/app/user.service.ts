import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';
import { text } from '@angular/core/src/render3';
import { HttpObserve } from '../../node_modules/@angular/common/http/src/client';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    'charset': 'UTF-8',
    'Access-Control-Allow-Origin': '*'
  })
}
@Injectable({
  providedIn: 'root'
})


export class UserService {

  private baseUrl = 'http://localhost:1234/paymentWallet';
  //show balance variable
  accountNo : any;
  password : string;

  constructor(private http:HttpClient) {}

  public createAccount(user) : any{
    return this.http.post(`${this.baseUrl}`+`/createAccount`, user);
  }


  public showBalance(user) : Observable<any>  {
    this.accountNo  = user.accountNo;
    this.password = user.password;
    return this.http.get(`${this.baseUrl}/showBalance/${this.accountNo}/${this.password}`, { responseType: 'text' });
  }

  public depositAmount(user) : any {
    this.accountNo = user.accountNo;
    this.password = user.password;
    let amount = user.amount;
    return this.http.put(`${this.baseUrl}/deposit/${this.accountNo}/${this.password}/${amount}`,{responseType : 'text'});
  }

  public withdrawAmount(user) : any {
    this.accountNo = user.accountNo;
    this.password = user.password;
    let amount = user.amount;
    return this.http.put(`${this.baseUrl}/withdraw/${this.accountNo}/${this.password}/${amount}`,{responseType : 'text'});
  }

  public fundTransfer(user):any{
    this.accountNo = user.accountNo;
    this.password = user.password;
    let destAccountNo = user.destAccountNo;
    let amount = user.amount;
    return this.http.put(`${this.baseUrl}/fundtransfer/${this.accountNo}/${this.password}/${destAccountNo}/${amount}`,{responseType : 'text'})
  }

  public printTransaction(user):Observable<any>{
    this.accountNo = user.accountNo;
    return this.http.get(`${this.baseUrl}/printTransaction/${this.accountNo}/`);
  }


}
