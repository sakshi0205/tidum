package com.cg.page;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Then;

public class RegistrationPage {
	
	WebDriver driver;
	
	@FindBy(xpath="/html/body/div/h2")
	WebElement heading;
	
	@FindBy(id="txtFullName")
	WebElement fullname;
	
	@FindBy(id="txtEmail")
	WebElement email;

	@FindBy(id="txtPhone")
	WebElement mobile;

	@FindBy(id="gender")
	WebElement gender;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/select")
	WebElement city;

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	WebElement state;
	
	@FindBy(id="txtCardholderName")
	WebElement subcategory;
	
	@FindBy(id="txtDebit")
	WebElement papername;
	
	@FindBy(id="txtCvv")
	WebElement authors;

	@FindBy(id="txtMonth")
	WebElement company;
	
	@FindBy(id="txtYear")
	WebElement designation;
	
	@FindBy(id="btnPayment")
	WebElement confirm;
	
	
	public RegistrationPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setFullname(String fullname) {
		this.fullname.sendKeys(fullname);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}
	
	public void setGender(String gender) {
		driver.findElement(By.cssSelector("input[type='radio'][value='"+gender+"']")).click();		
	}

	public void setCity(String city) {
		Select cityselect = new Select(this.city);
		cityselect.selectByVisibleText(city);
	}

	public void setState(String state) {
		Select stateselect = new Select(this.state);
		stateselect.selectByVisibleText(state);
		
	}

	public void setSubcategory(String subcategory) {
		this.subcategory.sendKeys(subcategory);
	}

	public void setPapername(String papername) {
		this.papername.sendKeys(papername);
	}

	public void setAuthors(String authors) {
		this.authors.sendKeys(authors);
	}

	public void setCompany(String company) {
		this.company.sendKeys(company);
	}

	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}

	public void clickConfirm() {
		confirm.click();
	}
	
	public void back() {
		driver.navigate().back();
	}

	public void handleAlert() {
		
		Alert alert = driver.switchTo().alert();
		System.err.println("Alert Message : "+alert.getText());
		alert.accept();
	}
	
	public void wait1() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
