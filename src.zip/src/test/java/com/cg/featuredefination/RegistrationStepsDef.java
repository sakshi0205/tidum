package com.cg.featuredefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.page.LoginPage;
import com.cg.page.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepsDef {
	
	static WebDriver driver;
	static RegistrationPage page;
	
	public static void initialiseRegistration() {
		driver = LoginStepsDef.driver;
		page = new RegistrationPage(driver);
	}
	
	@Given("^Browser is launched and login page is done$")
	public void browser_is_launched_and_login_page_is_done() {
	    if(driver == null) {
	    	System.setProperty("webdriver.chrome.driver","./softwares\\chromedriver.exe");
	 	    driver = new ChromeDriver();
	 	    driver.get("file:///D:/Study%20Material/Module%204/VV%20AT%20M4_MPT%20Sample%20Que/login.html");
	 	    LoginPage loginpage = new LoginPage(driver);
	 	    page = new RegistrationPage(driver);
	 	    loginpage.setUsername("vrl");
	 	    loginpage.setPassword("vrl1234");
	 	    loginpage.clickLogin();
	 	    System.out.println("Browser Launched !!");
	    }
	   
	}
	
	@When("^Verify the title Capgemini International Research journal$")
	public void verify_the_title_Capgemini_International_Research_journal()  {

	  
	}

	@When("^Enter full name (.*)$")
	public void enter_full_name(String name)  {		
	
		page.setFullname(name);
	}

	@When("^Enter Email (.*)$")
	public void enter_Email(String email)  {

	  page.setEmail(email);
	}

	@When("^Enter mobile (.*)$")
	public void enter_mobile(String mobile)  {

	  page.setMobile(mobile);
	}

	@When("^Enter Gender (.*)$")
	public void enter_Gender(String gender)  {

	  page.setGender(gender);
	}

	@When("^Enter City (.*)$")
	public void enter_City(String city)  {

	  page.setCity(city);
	}

	@When("^Enter State (.*)$")
	public void enter_State(String state)  {

	  page.setState(state);
	}

	@When("^Enter Sub category (.*)$")
	public void enter_Sub_category(String subcategory)  {

	  page.setSubcategory(subcategory);
	}

	@When("^Enter Sub paper name (.*)$")
	public void enter_Sub_paper_name(String papername)  {

	  page.setPapername(papername);
	}

	@When("^Enter number of authors (.*)$")
	public void enter_number_of_authors(String authors)  {

	  page.setAuthors(authors);
	}

	@When("^Enter Company name (.*)$")
	public void enter_Company_name(String company)  {

	  page.setCompany(company);
	}

	@When("^Enter designation (.*)$")
	public void enter_designation(String designation)  {

	  page.setDesignation(designation);
	}
	
	@Then("^click confirm registration button$")
	public void click_confirm_registration_button()  {
		
		page.clickConfirm();
		page.wait1();
		page.handleAlert();
	}
	
}
