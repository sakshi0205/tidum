package com.cg.featuredefination;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.page.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepsDef {
	
	static WebDriver driver;
	static LoginPage loginpage;
	
	@Given("^Browser is launched and login page is available$")
	public void browser_is_launched_and_login_page_is_available() {
	    if(driver == null) {
	    	System.setProperty("webdriver.chrome.driver","./softwares\\chromedriver.exe");
	 	    driver = new ChromeDriver();
	 	    driver.get("file:///D:/Study%20Material/Module%204/VV%20AT%20M4_MPT%20Sample%20Que/login.html");
	 	    loginpage = new LoginPage(driver);	 	    
	 	    System.out.println("Browser Launched !!");
	    }
	   
	}

	@Then("^Verify login page heading as “Paper submission for International Journal”$")
	public void verify_login_page_heading_as_Paper_submission_for_International_Journal() {	    
		
		Assert.assertEquals("Paper Submission for International Journal", loginpage.getHeading());
		
	}
	
	@Then("^click on Subcategories link$")
	public void click_on_Subcategories_link() {
		loginpage.clickSubCategories();
	}

	@Then("^nevigate back to login page$")
	public void nevigate_back_to_login_page() {
	    loginpage.back();	   
	}

	@When("^Enter Username (.*) and (.*)$")
	public void enter_Username_and_vrl(String username, String password) {
	    loginpage.setUsername(username);
	    loginpage.setPassword(password);	   
	}

	@When("^press login button$")
	public void press_login_button() {
	   loginpage.clickLogin();
	}

	@Then("^it displays error messsage as Please enter userName\\.$")
	public void it_displays_error_messsage_as_Please_enter_userName() {
		
	    System.err.println("Please Enter Username.");	   
	}

	@Then("^it displays error messsage as Please enter Password\\.$")
	public void it_displays_error_messsage_as_Please_enter_Password() {
		System.err.println("Please Enter Password.");	   	   
	}

	@Then("^user nevigates to registration page$")
	public void user_nevigates_to_registration_page() {
	    System.err.println("Login Successful !! Nevigating to registration page");	
	    RegistrationStepsDef.initialiseRegistration();
	}

	@Then("^wait$")
	public void wait1() throws InterruptedException{
		Thread.sleep(3000);
	}

}
