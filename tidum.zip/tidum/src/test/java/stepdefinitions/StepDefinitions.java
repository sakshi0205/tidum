package stepdefinitions;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import locators.Locators;

public class StepDefinitions {
	@Given("^user is on the login page$")
	public void user_is_on_the_login_page() throws Throwable {
		factory.methods.openbrowser("C:/Users/sakraut/Desktop/login.html");
	}

	@When("^user verifies the title$")
	public void user_verifies_the_title() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
	factory.methods.SendValue(" Hotel Booking Application ", locators.Locators.title);
	}

	@When("^enters the username and password$")
	public void enters_the_username_and_password() throws Throwable {
		factory.methods.SendValue("capgemini", locators.Locators.username);
		factory.methods.SendValue("capg1234", locators.Locators.password);

	}

	@When("^clicks login page$")
	public void clicks_login_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
       factory.methods.clickmethod(Locators.login);
	}

	@Then("^user navigates to the hotel booking$")
	public void user_navigates_to_the_hotel_booking() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.openbrowser("C:/Users/sakraut/Desktop/hotelbooking.html");
	}

	@Given("^user is on the hotel booking page$")
	public void user_is_on_the_hotel_booking_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
       
	}

	@When("^enters the firstname and last name$")
	public void enters_the_firstname_and_last_name() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("sakshi", locators.Locators.FirstName);
		factory.methods.SendValue("raut", locators.Locators.LastName);
	}

	@When("^enters the email$")
	public void enters_the_email() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("sakshi@cap.com", locators.Locators.Email);
	}

	@When("^enters mobile no$")
	public void enters_mobile_no() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("9865321425", locators.Locators.MobileNo);
	}

	@When("^enters number of people staying$")
	public void enters_number_of_people_staying() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("3", locators.Locators.NoGuest);
		
	}

	@When("^enters the address$")
	public void enters_the_address() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("capgemini", locators.Locators.Address);
	}

	@When("^enters the city and state$")
	public void enters_the_city_and_state() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("chennai", locators.Locators.City);
		factory.methods.SendValue("maharashtra", locators.Locators.State);
	}

	@When("^enters card holders name$")
	public void enters_card_holders_name() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("sakshi", locators.Locators.CardName);
	}

	@When("^enters debit card number$")
	public void enters_debit_card_number() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("98564253632", locators.Locators.CardNo);
		factory.methods.SendValue("123", locators.Locators.Cvv);
	}

	@When("^enters card expiration date$")
	public void enters_card_expiration_date() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("12", locators.Locators.ExpireMonth);
	}

	@When("^enters card expiration year$")
	public void enters_card_expiration_year() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		factory.methods.SendValue("12", locators.Locators.ExpireYear);
	}

	@When("^clicks confirm booking button$")
	public void clicks_confirm_booking_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		 factory.methods.clickmethod(Locators.Submit);
	}

	@Then("^confirm booking mesage is displayed$")
	public void confirm_booking_mesage_is_displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
        
	}

}
