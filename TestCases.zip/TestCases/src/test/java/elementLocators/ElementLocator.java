package elementLocators;
import org.openqa.selenium.By;

public class ElementLocator {
	public static By loginlink=By.xpath("//input[@value='Login']");
	public static By userName=By.xpath("//input[@name='userName']");
	public static By password=By.xpath("//input[@name='userPwd']");
	public static By loginTitle=By.xpath("//h1[text()=' Hotel Booking Application ']");
	public static By firstName=By.id("txtFirstName");
	public static By bookButton=By.id("btnPayment");
	public static By lastName=By.id("txtLastName");
	public static By email=By.id("txtEmail");
	public static By mobile=By.id("txtPhone");
	public static By address=By.xpath("//textarea");
	public static By city=By.xpath("//select[@name='city']");
	public static By state=By.xpath("//select[@name='state']");
	public static By persons=By.xpath("//select[@name='persons']");
	public static By cardHolderName=By.id("txtCardholderName");
	public static By cardNumber=By.id("txtDebit");
	public static By cvv=By.id("txtCvv");
	public static By expiryMon=By.id("txtMonth");
	public static By expiryYear=By.id("txtYear");
}
