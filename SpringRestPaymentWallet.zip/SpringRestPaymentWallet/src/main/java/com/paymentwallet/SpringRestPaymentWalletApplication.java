package com.paymentwallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestPaymentWalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestPaymentWalletApplication.class, args);
	}

}
