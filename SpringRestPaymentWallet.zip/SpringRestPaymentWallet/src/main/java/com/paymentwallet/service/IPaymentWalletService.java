package com.paymentwallet.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.paymentwallet.entity.Transaction;
import com.paymentwallet.entity.User;
import com.paymentwallet.exception.AccountNotFoundException;

public interface IPaymentWalletService {

	public User createUserAccount(User user);

	public String showBalance(int accountNo, String password) throws AccountNotFoundException;

	public User depositAmount(int accountNo, String password, int amount) throws AccountNotFoundException;

	public User withdrawAmount(int accountNo, String password, int amount) throws AccountNotFoundException;

	public User fundTransfer(int accountNo, String password, int destAccountNo, int amount)throws AccountNotFoundException;

	public List<Transaction> printTransaction(int accountNo) throws AccountNotFoundException;

	///////////////////////Validation///////////////////////
	
	public Optional<User>  validateAccount(int accountNo) throws AccountNotFoundException;
	public int checkBalance(int accountNo, int balance);
	public boolean checkAmount(int amount);

}
