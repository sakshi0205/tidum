package com.paymentwallet.service;




import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paymentwallet.entity.Transaction;
import com.paymentwallet.entity.User;
import com.paymentwallet.exception.AccountNotFoundException;
import com.paymentwallet.exception.InsufficientBalanceException;
import com.paymentwallet.repository.PaymentWalletRepository;


@Service
@Transactional
public class PaymentWalletService implements IPaymentWalletService{
	@Autowired 
	PaymentWalletRepository repository;

	static Random random = new Random();

	public int generateAccountNo() {
		int n = random.nextInt(100000);
		return n;
	}
	
	public int generateRandomTransactionID() {
		int t = random.nextInt(100);
		return t;
	}
	
	@Override
	public User createUserAccount(User user) {
		User entity =  new User();
		Integer accountNo = generateAccountNo();
		
		entity.setAccountNo(accountNo);
		entity.setBalance(0);
		entity.setUserName(user.getUserName());
		entity.setPassword(user.getPassword());
		entity.setUserEmailId(user.getUserEmailId());
		entity.setUserPhoneNo(user.getUserPhoneNo());
		return repository.saveAndFlush(entity);
	}

	@Override
	public String showBalance(int accountNo,String password) throws AccountNotFoundException {
		Optional<User> opt=repository.findById(accountNo);
		if(opt.isPresent()) {
			User entity=opt.get();
			if(password.equals(entity.getPassword())){
				int balance = entity.getBalance();
				return accountNo + " your account balance is:" + balance;
			}
			else {
				return "Wrong Password";
			}
		}
		else {
			throw new AccountNotFoundException("Account does not exist");
		}
	}

	@Override
	public User depositAmount(int accountNo, String password, int amount) throws AccountNotFoundException {
		Optional<User> opt=repository.findById(accountNo);
		if(opt.isPresent())
		 {
			User entity=opt.get();
			if(password.equals(entity.getPassword())){
				int balance = entity.getBalance()+amount;
				entity.setBalance(balance);
				
				
				//add transaction to table 
				Transaction tb = new Transaction();
				Date date= new Date();
				long time = date.getTime();
				Timestamp ts = new Timestamp(time);
				Integer tid = generateRandomTransactionID();
				tb.setTransactionId(tid);
				tb.setTransactionType("Deposit");
				tb.setToAccountNo(null);
				tb.setTransactionDate(ts);
				tb.setAmount(amount);
				tb.setAccountId(accountNo);	
				repository.saveAndFlush(tb);	//Transaction added successfully
				
				
				return entity;
			}
			else {
				return null;
			}
			
		 } 
		else {
			throw new AccountNotFoundException("Account does not exist");		
		}
			
	}

	@Override
	public User withdrawAmount(int accountNo, String password, int amount) throws AccountNotFoundException {
		Optional<User> opt=repository.findById(accountNo);
		if(opt.isPresent())
		 {
			User entity=opt.get();
			if(password.equals(entity.getPassword())){
				int balance = entity.getBalance()-amount;
				entity.setBalance(balance);
				
				//add transaction to table 
				Transaction tb = new Transaction();
				Date date= new Date();
				long time = date.getTime();
				Timestamp ts = new Timestamp(time);
				Integer tid = generateRandomTransactionID();
				tb.setTransactionId(tid);
				tb.setTransactionType("Withdraw");
				tb.setToAccountNo(null);
				tb.setTransactionDate(ts);
				tb.setAmount(amount);
				tb.setAccountId(accountNo);	
				repository.saveAndFlush(tb);	//Transaction added successfully
				return entity;
			}
			else {
				return null;
			}
			
		 } 
		else {
			throw new AccountNotFoundException("Account does not exist");		
		}
	}

	@Override
	public User fundTransfer(int accountNo, String password, int destAccountNo, int amount) throws AccountNotFoundException {
		Optional<User> opt1=validateAccount(accountNo);
		Optional<User> opt2=validateAccount(destAccountNo);
	
		User sourceEntity=opt1.get();
		User destinationEntity=opt2.get();
		
		if(password.equals(sourceEntity.getPassword())){
			amount = checkBalance(accountNo,amount);
			
			int balance = sourceEntity.getBalance()-amount;
			sourceEntity.setBalance(balance);
				
			int destbalance = destinationEntity.getBalance()+amount;
			destinationEntity.setBalance(destbalance);
			
			//add transaction to table 
			Transaction tb = new Transaction();
			Date date= new Date();
			long time = date.getTime();
			Timestamp ts = new Timestamp(time);
			Integer tid = generateRandomTransactionID();
			tb.setTransactionId(tid);
			tb.setAccountId(accountNo);
			tb.setToAccountNo(destAccountNo);
			tb.setAmount(amount);
			tb.setTransactionType("Fund Transfer");
			tb.setTransactionDate(ts);
				
			return sourceEntity;
		}
		else {
			return null;
		}	
	}
	
	@Override
	public List<Transaction> printTransaction(int accountNo) throws AccountNotFoundException {
		// TODO Auto-generated method stub
		
		List<Transaction> entityList=repository.findTransactionById(accountNo);
		if(entityList.isEmpty() || entityList.size()==0) {
			throw new AccountNotFoundException("Transaction details does not exist");
		}
		List<Transaction>list = new ArrayList();
		for (Transaction entity : entityList) {
			Transaction t = new Transaction();
			t.setTransactionId(entity.getTransactionId());
			t.setAccountId(entity.getAccountNo());
			t.setAmount(entity.getAmount());
			t.setToAccountNo(entity.getToAccountNo());
			t.setTransactionDate(entity.getTransactionDate());
			t.setTransactionType(entity.getTransactionType());
			list.add(t);
		}
		return list;

	}	

	

	/////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////Validation///////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	@Override
	public Optional<User> validateAccount(int accountNo) throws AccountNotFoundException {
		Optional<User> opt=repository.findById(accountNo);
		if(opt.isPresent()) {
			return opt;
		}
		else {
			throw new AccountNotFoundException(accountNo+" does not found");
		}
	}

	@Override
	public int checkBalance(int accountNo, int amount) {
		Optional<User> opt=repository.findById(accountNo);
		User sourceEntity=opt.get();
		if(amount <= sourceEntity.getBalance()) {
			return amount;
		}
		else {
			throw new InsufficientBalanceException("insufficient balance in account");
		}
	}

	@Override
	public boolean checkAmount(int amount) {
		if(amount>0) {
			return true;
		}
		else {
			return false;
		}
	}

	
	
}
