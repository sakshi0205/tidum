package com.paymentwallet.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class AccountNotFoundException extends Exception{
	
	public AccountNotFoundException() {
		super();
	}
	public AccountNotFoundException(String errors) {
		super(errors);
	}

}
