package com.paymentwallet.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class InsufficientBalanceException extends RuntimeException {
	
	public InsufficientBalanceException() {
		super();
	}
	public InsufficientBalanceException(String errors) {
		super(errors);
	}

}
