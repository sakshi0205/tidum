package com.paymentwallet.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.paymentwallet.entity.Transaction;
import com.paymentwallet.entity.User;

@Repository
public interface PaymentWalletRepository extends JpaRepository<User, Integer> {

	void saveAndFlush(Transaction tb);

	@Query("select t from Transaction t where accountNo = :accountNo")
	List<Transaction> findTransactionById(int accountNo);

}
