package com.paymentwallet.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.Repository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.paymentwallet.entity.Transaction;
import com.paymentwallet.entity.User;
import com.paymentwallet.exception.AccountNotFoundException;
import com.paymentwallet.service.IPaymentWalletService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/paymentWallet")
public class PaymentWalletController {
	
	@Autowired
	IPaymentWalletService paymentWalletService;
	
	//result variable 
	String result;
	
	 @PostMapping("/createAccount")
     public User createAccount(@Valid @RequestBody User user) {
		User result = paymentWalletService.createUserAccount(user);
        //return new ResponseEntity<User>(result, HttpStatus.OK);
		 return result;

     }
	 
	 
	 @GetMapping(value="/showBalance/{accountNo}/{password}")
	public ResponseEntity<String> showBalance(@PathVariable("accountNo") int accountNo,@PathVariable("password") String password) throws AccountNotFoundException{ 
		result= paymentWalletService.showBalance(accountNo,password);
		//return ResponseEntity.ok(result);
		return ResponseEntity.ok().body(result);
	}
	 
	
	@PutMapping(value = "/deposit/{accountNo}/{password}/{amount}")
	public User depositAmount(@PathVariable("accountNo") int accountNo,@PathVariable("password") String password,@PathVariable("amount") int amount) throws AccountNotFoundException{
		if(paymentWalletService.checkAmount(amount)) {
			User result = paymentWalletService.depositAmount(accountNo, password,amount);
			return  result;
		}
		else {
			User result =  null; 
			return  result;
		}
		
	}
	
	@PutMapping(value = "/withdraw/{accountNo}/{password}/{amount}")
	public User withdrawAmount(@PathVariable("accountNo") int accountNo,@PathVariable("password") String password,@PathVariable("amount") int amount) throws AccountNotFoundException{		
		if(paymentWalletService.checkAmount(amount)) {
			User result =  paymentWalletService.withdrawAmount(accountNo, password,amount);
			return result;

		}
		else {
			result = "amount should be greater than 0"; 
			return null;

		}
	}
	
	@PutMapping(value = "/fundtransfer/{accountNo}/{password}/{destAccountNo}/{amount}")
	public User fundTransfer(@PathVariable("accountNo") int accountNo,@PathVariable("password") String password,@PathVariable("destAccountNo") int destAccountNo,@PathVariable("amount") int amount) throws AccountNotFoundException{
		if(paymentWalletService.checkAmount(amount)) {
			User result =  paymentWalletService.fundTransfer(accountNo, password,destAccountNo,amount);
			return result;

		}
		else {
			result = "amount should be greater than 0"; 
			return null;
		}
	}
	
	@GetMapping(value = "/printTransaction/{accountNo}/")
	public List<Transaction> printTransaction(@PathVariable("accountNo") int accountNo) throws AccountNotFoundException{
		List<Transaction> result = paymentWalletService.printTransaction(accountNo);
		return result;
	}

}