package com.paymentwallet.entity;



import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction")
public class Transaction {
	
	@Id
	@Column(name = "transactionId")
	private Integer transactionId;
	private String transactionType;
	@Column(name = "destAccountNo")
	private Integer destAccountNo;
	private Timestamp transactionDate;
	private Integer amount;
	@Column(name = "accountNo")
	private Integer accountNo;
	
	//private UserBean userBean;

	
	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public Integer getToAccountNo() {
		return destAccountNo;
	}


	public void setToAccountNo(Integer destAccountNo) {
		this.destAccountNo = destAccountNo;
	}


	public Timestamp getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(Timestamp getDate) {
		this.transactionDate = getDate;
	}


	public int getAmount() {
		return amount;
	}


	public void setAmount(int amount) {
		this.amount = amount;
	}


	public Integer getAccountNo() {
		return accountNo;
	}


	public void setAccountId(Integer accountNo) {
		this.accountNo = accountNo;
	}
	
	@Override
	public String toString() {
		return "TransactionBean [TransactionId=" + transactionId + ", TransactionType=" + transactionType
				+ ", Destination Account No==" + destAccountNo + ", TransactionDate=" + transactionDate + ", Amount=" + amount
				+ ", AccountNo=" + accountNo + "]";
	}

}
