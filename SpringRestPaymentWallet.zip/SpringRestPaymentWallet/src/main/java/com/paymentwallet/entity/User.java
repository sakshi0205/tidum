package com.paymentwallet.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Pattern.Flag;
import javax.validation.constraints.Size;

@Entity
@Table(name="paymentWallet")
public class User {
	@NotBlank(message = "Name may not be blank")
	@Size(min = 3, max = 20,message = "name containe at least 3 character")
	@Column(name = "userName")
	private String userName;
	
	@NotBlank(message = "password may not be blank")
	@Pattern(regexp = "^(?=.*\\d).{4,8}$", flags = Flag.UNICODE_CASE)
	@Column(name="pass")
	private String password;

	@NotBlank(message = "email may not be blank")
	@Pattern(regexp=".+@.+\\.[a-z]+",message = "email should be proper")
	@Column(name="email")
	private String userEmailId;
	
	@NotBlank(message = "phone number may not be blank")
	@Pattern(regexp="(^$|[0-9]{10})" ,message = "mobile number should be proper")
	@Column(name = "phoneNo")
	private String userPhoneNo;
	
	@Id
	@Column(name = "accountNo")
	private Integer accountNo;
	
	@Column(name="balance")
	private Integer balance=0;
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUserEmailId() {
		return userEmailId;
	}
	
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	
	public String getUserPhoneNo() {
		return userPhoneNo;
	}
	
	public void setUserPhoneNo(String userPhoneNo) {
		this.userPhoneNo = userPhoneNo;
	}
	
	public Integer getAccountNo() {
		return accountNo;
	}
	
	public void setAccountNo(Integer accountNo) {
		this.accountNo = accountNo;
	}
	
	public Integer getBalance() {
		return balance;
	}
	
	public void setBalance(Integer balance) {
		this.balance = balance;
	}


}
